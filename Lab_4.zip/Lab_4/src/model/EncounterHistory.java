/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class EncounterHistory {
    private ArrayList<Patient> history;
    
    public EncounterHistory(){
        this.history= new ArrayList<Patient>();
    }

    public ArrayList<Patient> getHistory() {
        return history;
    }

    public void setHistory(ArrayList<Patient> history) {
        this.history = history;
    }
    public Patient addNewPatient(){
        Patient newPatient = new Patient();
        history.add(newPatient);
        return newPatient;
    }
    public void deletePatient(Patient p){
        history.remove(p);
    }
}
